"use client"

import handler from "../api/chatbot/ask"

export default function SyntheticV0PageForDeployment() {
  return <handler />
}