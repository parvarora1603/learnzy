import { db } from "../../firebase/firebaseConfig"
import { doc, getDoc, updateDoc } from "firebase/firestore"

export default async function handler(req, res) {
  if (req.method === "GET") {
    try {
      const { assignmentId } = req.query

      if (!assignmentId) {
        return res.status(400).json({ error: "Assignment ID is required" })
      }

      // Get the assignment
      const assignmentRef = doc(db, "assignments", assignmentId)
      const assignmentSnap = await getDoc(assignmentRef)

      if (!assignmentSnap.exists()) {
        return res.status(404).json({ error: "Assignment not found" })
      }

      const assignmentData = assignmentSnap.data()

      // Verify this is a written assignment
      if (assignmentData.type !== "written") {
        return res.status(400).json({ error: "This is not a written assignment" })
      }

      // Get all student submissions
      const submissions = assignmentData.submissions

      // Get student details for each submission
      const submissionsWithDetails = await Promise.all(
        submissions.map(async (submission) => {
          const userRef = doc(db, "users", submission.studentId)
          const userSnap = await getDoc(userRef)

          if (userSnap.exists()) {
            const userData = userSnap.data()
            return {
              ...submission,
              studentName: userData.name,
              studentEmail: userData.email,
            }
          }

          return submission
        }),
      )

      return res.status(200).json({
        assignmentDetails: {
          id: assignmentId,
          chapter: assignmentData.chapter,
          topic: assignmentData.topic,
          difficulty: assignmentData.difficulty,
          questions: assignmentData.questions,
        },
        submissions: submissionsWithDetails,
      })
    } catch (error) {
      console.error("Written results error:", error)
      return res.status(500).json({ error: "Failed to get written results" })
    }
  } else if (req.method === "POST") {
    // This endpoint also handles reviewing written assignments
    try {
      const { assignmentId, studentId, feedback, score } = req.body

      if (!assignmentId || !studentId || feedback === undefined || score === undefined) {
        return res.status(400).json({ error: "Assignment ID, student ID, feedback, and score are required" })
      }

      // Get the assignment
      const assignmentRef = doc(db, "assignments", assignmentId)
      const assignmentSnap = await getDoc(assignmentRef)

      if (!assignmentSnap.exists()) {
        return res.status(404).json({ error: "Assignment not found" })
      }

      const assignmentData = assignmentSnap.data()

      // Find the student's submission
      const submissions = assignmentData.submissions
      const submissionIndex = submissions.findIndex((sub) => sub.studentId === studentId)

      if (submissionIndex === -1) {
        return res.status(404).json({ error: "Submission not found" })
      }

      // Update the submission with feedback and score
      submissions[submissionIndex] = {
        ...submissions[submissionIndex],
        feedback,
        score,
        reviewed: true,
        reviewedAt: new Date().toISOString(),
      }

      // Update the assignment
      await updateDoc(assignmentRef, {
        submissions,
      })

      return res.status(200).json({ message: "Review submitted successfully" })
    } catch (error) {
      console.error("Review submission error:", error)
      return res.status(500).json({ error: "Failed to submit review" })
    }
  } else {
    return res.status(405).json({ error: "Method not allowed" })
  }
}

