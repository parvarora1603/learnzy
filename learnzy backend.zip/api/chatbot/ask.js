import { db } from "../../firebase/firebaseConfig"
import { collection, addDoc } from "firebase/firestore"
import { GoogleGenerativeAI } from "@google/generative-ai"

// Initialize the Google Generative AI with your API key
const genAI = new GoogleGenerativeAI("AIzaSyDrpyFtEstO1DunXgS9y0xb71ubvwfD_YU")

export default async function handler(req, res) {
  if (req.method !== "POST") {
    return res.status(405).json({ error: "Method not allowed" })
  }

  try {
    const { question, studentId } = req.body

    if (!question || !studentId) {
      return res.status(400).json({ error: "Question and studentId are required" })
    }

    // Set up the model with the context
    const model = genAI.getGenerativeModel({ model: "gemini-pro" })

    // Create a prompt with context
    const prompt = `You are a science teacher for Class 10 students. Answer briefly and in student-friendly language. 
    
    Question: ${question}`

    // Generate content
    const result = await model.generateContent(prompt)
    const response = await result.response
    const answer = response.text()

    // Save the Q&A as a note
    await addDoc(collection(db, "savedNotes"), {
      studentId,
      question,
      noteText: answer,
      timestamp: new Date().toISOString(),
    })

    return res.status(200).json({ answer })
  } catch (error) {
    console.error("Chatbot error:", error)
    return res.status(500).json({ error: "Failed to process question" })
  }
}

