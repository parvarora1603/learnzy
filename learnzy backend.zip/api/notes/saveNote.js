import { db } from "../../firebase/firebaseConfig"
import { collection, addDoc } from "firebase/firestore"

export default async function handler(req, res) {
  if (req.method !== "POST") {
    return res.status(405).json({ error: "Method not allowed" })
  }

  try {
    const { studentId, noteText } = req.body

    if (!studentId || !noteText) {
      return res.status(400).json({ error: "Student ID and note text are required" })
    }

    // Save the note to Firestore
    const noteData = {
      studentId,
      noteText,
      timestamp: new Date().toISOString(),
    }

    const docRef = await addDoc(collection(db, "savedNotes"), noteData)

    return res.status(201).json({
      id: docRef.id,
      ...noteData,
    })
  } catch (error) {
    console.error("Save note error:", error)
    return res.status(500).json({ error: "Failed to save note" })
  }
}

