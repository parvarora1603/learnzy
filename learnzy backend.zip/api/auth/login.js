import { auth } from "../../firebase/firebaseConfig"
import { signInWithEmailAndPassword } from "firebase/auth"

export default async function handler(req, res) {
  if (req.method !== "POST") {
    return res.status(405).json({ error: "Method not allowed" })
  }

  try {
    const { email, password } = req.body

    if (!email || !password) {
      return res.status(400).json({ error: "Email and password are required" })
    }

    const userCredential = await signInWithEmailAndPassword(auth, email, password)
    const user = userCredential.user

    return res.status(200).json({
      uid: user.uid,
      email: user.email,
    })
  } catch (error) {
    console.error("Login error:", error)
    return res.status(401).json({ error: "Authentication failed" })
  }
}

