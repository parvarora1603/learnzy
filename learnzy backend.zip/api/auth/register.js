import { auth, db } from "../../firebase/firebaseConfig"
import { createUserWithEmailAndPassword } from "firebase/auth"
import { doc, setDoc } from "firebase/firestore"

export default async function handler(req, res) {
  if (req.method !== "POST") {
    return res.status(405).json({ error: "Method not allowed" })
  }

  try {
    const { email, password, name, role } = req.body

    if (!email || !password || !name || !role) {
      return res.status(400).json({ error: "Email, password, name, and role are required" })
    }

    // Validate role
    if (role !== "teacher" && role !== "student") {
      return res.status(400).json({ error: 'Role must be either "teacher" or "student"' })
    }

    // Create user in Firebase Auth
    const userCredential = await createUserWithEmailAndPassword(auth, email, password)
    const user = userCredential.user

    // Store additional user data in Firestore
    await setDoc(doc(db, "users", user.uid), {
      uid: user.uid,
      name,
      email,
      role,
      createdAt: new Date().toISOString(),
    })

    return res.status(201).json({
      uid: user.uid,
      email: user.email,
      name,
      role,
    })
  } catch (error) {
    console.error("Registration error:", error)

    if (error.code === "auth/email-already-in-use") {
      return res.status(409).json({ error: "Email already in use" })
    }

    return res.status(500).json({ error: "Registration failed" })
  }
}

