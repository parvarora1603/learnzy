import { db } from "../../firebase/firebaseConfig"
import { collection, query, where, getDocs } from "firebase/firestore"

export default async function handler(req, res) {
  if (req.method !== "GET") {
    return res.status(405).json({ error: "Method not allowed" })
  }

  try {
    const { teacherId } = req.query

    if (!teacherId) {
      return res.status(400).json({ error: "Teacher ID is required" })
    }

    // Get assignments created by this teacher
    const assignmentsRef = collection(db, "assignments")
    const q = query(assignmentsRef, where("createdBy", "==", teacherId))
    const assignmentsSnap = await getDocs(q)

    const assignments = []

    assignmentsSnap.forEach((doc) => {
      assignments.push({
        id: doc.id,
        ...doc.data(),
        submissionCount: doc.data().submissions.length,
      })
    })

    return res.status(200).json(assignments)
  } catch (error) {
    console.error("Get teacher assignments error:", error)
    return res.status(500).json({ error: "Failed to get assignments" })
  }
}

