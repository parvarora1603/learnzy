import { db } from "../../firebase/firebaseConfig"
import { collection, getDocs } from "firebase/firestore"

export default async function handler(req, res) {
  if (req.method !== "GET") {
    return res.status(405).json({ error: "Method not allowed" })
  }

  try {
    const { studentId } = req.query

    if (!studentId) {
      return res.status(400).json({ error: "Student ID is required" })
    }

    // Get all assignments
    const assignmentsRef = collection(db, "assignments")
    const assignmentsSnap = await getDocs(assignmentsRef)

    const assignments = []
    const now = new Date()

    assignmentsSnap.forEach((doc) => {
      const assignment = {
        id: doc.id,
        ...doc.data(),
      }

      // Check if student has already submitted
      const hasSubmitted = assignment.submissions.some((sub) => sub.studentId === studentId)

      // Calculate if assignment is due soon (within 24 hours)
      const dueDateTime = new Date(`${assignment.dueDate}T${assignment.dueTime}`)
      const timeDiff = dueDateTime.getTime() - now.getTime()
      const isDueSoon = timeDiff > 0 && timeDiff < 24 * 60 * 60 * 1000
      const isPastDue = timeDiff < 0

      assignments.push({
        ...assignment,
        hasSubmitted,
        isDueSoon,
        isPastDue,
      })
    })

    return res.status(200).json(assignments)
  } catch (error) {
    console.error("Get student assignments error:", error)
    return res.status(500).json({ error: "Failed to get assignments" })
  }
}

