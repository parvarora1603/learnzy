import { db } from "../../firebase/firebaseConfig"
import { doc, getDoc, updateDoc, arrayUnion } from "firebase/firestore"

export default async function handler(req, res) {
  if (req.method !== "POST") {
    return res.status(405).json({ error: "Method not allowed" })
  }

  try {
    const { assignmentId, studentId, answers } = req.body

    if (!assignmentId || !studentId || !answers) {
      return res.status(400).json({ error: "Assignment ID, student ID, and answers are required" })
    }

    // Get the assignment
    const assignmentRef = doc(db, "assignments", assignmentId)
    const assignmentSnap = await getDoc(assignmentRef)

    if (!assignmentSnap.exists()) {
      return res.status(404).json({ error: "Assignment not found" })
    }

    const assignmentData = assignmentSnap.data()

    // Verify this is a written assignment
    if (assignmentData.type !== "written") {
      return res.status(400).json({ error: "This is not a written assignment" })
    }

    // Prepare submission data
    const submission = {
      studentId,
      submittedAt: new Date().toISOString(),
      answers,
      reviewed: false, // Written assignments need manual review
    }

    // Update the assignment with the submission
    await updateDoc(assignmentRef, {
      submissions: arrayUnion(submission),
    })

    return res.status(200).json({
      message: "Written assignment submitted successfully",
      submittedAt: submission.submittedAt,
    })
  } catch (error) {
    console.error("Written submission error:", error)
    return res.status(500).json({ error: "Failed to submit written answers" })
  }
}

