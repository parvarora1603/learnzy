import { db } from "../../firebase/firebaseConfig"
import { collection, addDoc } from "firebase/firestore"

export default async function handler(req, res) {
  if (req.method !== "POST") {
    return res.status(405).json({ error: "Method not allowed" })
  }

  try {
    const { createdBy, type, chapter, topic, difficulty, questions, dueDate, dueTime } = req.body

    // Validate required fields
    if (!createdBy || !type || !chapter || !topic || !difficulty || !questions || !dueDate || !dueTime) {
      return res.status(400).json({ error: "All fields are required" })
    }

    // Validate type
    if (type !== "mcq" && type !== "written") {
      return res.status(400).json({ error: 'Type must be either "mcq" or "written"' })
    }

    // Validate difficulty
    if (!["easy", "medium", "tricky"].includes(difficulty)) {
      return res.status(400).json({ error: 'Difficulty must be "easy", "medium", or "tricky"' })
    }

    // Create assignment in Firestore
    const assignmentData = {
      createdBy,
      type,
      chapter,
      topic,
      difficulty,
      questions,
      dueDate,
      dueTime,
      createdAt: new Date().toISOString(),
      submissions: [],
    }

    const docRef = await addDoc(collection(db, "assignments"), assignmentData)

    return res.status(201).json({
      id: docRef.id,
      ...assignmentData,
    })
  } catch (error) {
    console.error("Assignment creation error:", error)
    return res.status(500).json({ error: "Failed to create assignment" })
  }
}

