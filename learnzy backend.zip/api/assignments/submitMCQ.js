import { db } from "../../firebase/firebaseConfig"
import { doc, getDoc, updateDoc, arrayUnion } from "firebase/firestore"

export default async function handler(req, res) {
  if (req.method !== "POST") {
    return res.status(405).json({ error: "Method not allowed" })
  }

  try {
    const { assignmentId, studentId, answers } = req.body

    if (!assignmentId || !studentId || !answers) {
      return res.status(400).json({ error: "Assignment ID, student ID, and answers are required" })
    }

    // Get the assignment
    const assignmentRef = doc(db, "assignments", assignmentId)
    const assignmentSnap = await getDoc(assignmentRef)

    if (!assignmentSnap.exists()) {
      return res.status(404).json({ error: "Assignment not found" })
    }

    const assignmentData = assignmentSnap.data()

    // Verify this is an MCQ assignment
    if (assignmentData.type !== "mcq") {
      return res.status(400).json({ error: "This is not an MCQ assignment" })
    }

    // Calculate score
    let score = 0
    const questions = assignmentData.questions

    if (questions.length !== answers.length) {
      return res.status(400).json({ error: "Number of answers does not match number of questions" })
    }

    for (let i = 0; i < questions.length; i++) {
      if (answers[i] === questions[i].correctAnswer) {
        score++
      }
    }

    // Prepare submission data
    const submission = {
      studentId,
      submittedAt: new Date().toISOString(),
      answers,
      score,
      totalQuestions: questions.length,
      reviewed: true, // MCQs are auto-reviewed
    }

    // Update the assignment with the submission
    await updateDoc(assignmentRef, {
      submissions: arrayUnion(submission),
    })

    return res.status(200).json({
      score,
      totalQuestions: questions.length,
      percentage: (score / questions.length) * 100,
    })
  } catch (error) {
    console.error("MCQ submission error:", error)
    return res.status(500).json({ error: "Failed to submit MCQ answers" })
  }
}

